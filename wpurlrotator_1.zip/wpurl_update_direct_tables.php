<?php

$tday = date("Y-m-d"); 


// Get count info
$get_count = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix ."wpurlrotator_count WHERE cid = '".$CurrID."' and ipnum = '".$pip."' and date = '".$tday."' and direct = '1' ");	

	if($get_count){
		// Name, ipnum and date exist
		//echo " this is currid ".$CurrID;
		$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_count SET directhits = directhits +1 WHERE cid = '".$CurrID."' and ipnum = '".$pip."' and date = '".$tday."'";
			$re=$wpdb->query($sql);

	} else {
		// Name and ipnum don't exist
		$ipcountry = visitor_country($pip);
		$sql=" INSERT INTO ".$wpdb->prefix."wpurlrotator_count (user, cid, date, ipnum, directip, directhits, country, referredby, camp_id) VALUES('$CurrName', '$CurrID','$tday','$pip',1, 1,'$ipcountry','$referredby', '$CurrCamp_ID')";
			$re=$wpdb->query($sql);
			
	}

$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_links SET direct = direct +1 WHERE id = ".$CurrID."";
			$re=$wpdb->query($sql);

function visitor_country($ip) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if(filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        if(filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        $result = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip))
                ->geoplugin_countryName;
        return $result <> NULL ? $result : "Unknown";
}

