<div align ="center";><a href="http://wpurlrotator.com" target="_blank">
<img src="<? echo $pi_path;?>images/Wp_Url_Rotator.png"></a></div>
