<center>
	<p>
<a href="admin.php?page=wpurlrotator">Close Help</a>
<div class="helpTable">
	

<b><h2>Rotator Campaign Help:</h2></b>
<p>
<b>Add New Rotator</b> - Add new rotator campaigns to your rotator/count tracker. Give the rotator a unique name. It cannot 
be the same as any post or page names - it <b>MUST BE UNIQUE</b> to your Wordpress installation. 
<p>
<b>Manage Links</b> - Click on the link name to add links to the rotator, and to manage links for the rotator.
<p>	
<b>Edit Rotator</b> - Change the name or default link of the rotator.
<p>	
<b>Rotator Default Link</b> - The current default link of the rotator to be used in the event that all of your 
links in the rotator become disabled, or in the rare event that your rotator can't find the next URL to serve.
<p>
<b>Links in Rotator</b> - The number of links assigned to the rotator campaign.
<p>
<b>Rotator Hits</b> - The number of total hits to the links in this rotator.
<p>
<b>Delete</b> - Delete this rotator campaign, along with all of its links and stats. <b>This cannot be undone!</b>
</div>

</center>
