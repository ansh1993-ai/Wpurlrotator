<?php

global $wpdb;

$rid = $_GET['rid'];
$id = $_GET['l'];
$type = $_GET['t'];

$link_table = $wpdb->prefix."wpurlrotator_links";
$count_table = $wpdb->prefix."wpurlrotator_count";

if($id){
	$sql = "UPDATE $link_table SET cnt = 0, direct = 0 WHERE camp_id = '$rid' and id = '$id' ";
	$wpdb->query($sql);

	$sql="DELETE FROM $count_table WHERE camp_id = '$rid' and cid ='$id'";
 
 $wpdb->query( $sql );
} elseif ($type == 'd') {
	// reset disabled
	$sql = "UPDATE $link_table SET cnt = 0, direct = 0 WHERE camp_id = '$rid' and enabled = 'N' ";
	$wpdb->query($sql);

	$sql = "DELETE FROM $count_table where camp_id = '$rid' and cid IN (select id from $link_table where camp_id = '$rid' and enabled = 'N')";
	$wpdb->query($sql);

} elseif ($type == 'e'){
	//reset enabled
	$sql = "UPDATE $link_table SET cnt = 0, direct = 0 WHERE camp_id = '$rid' and enabled = 'Y' ";
	$wpdb->query($sql);

	$sql = "DELETE FROM $count_table where camp_id = '$rid' and cid IN (select id from $link_table where camp_id = '$rid' and enabled = 'Y')";
	
	$wpdb->query($sql);

}

?>
<script type='text/javascript'>
window.location = "admin.php?page=wpurlrotator&rid=<?php echo $rid; ?>";

</script>