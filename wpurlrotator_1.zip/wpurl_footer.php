<?php
$img_path = plugins_url()."/".dirname(plugin_basename(__FILE__))."/img/";

?>
<P><P><center> <a href="http://wpurlrotator.com" target="_blank">WP URL Rotator</a> Created by <a href="http://mikeincolorado.com" target="_blank">Mike In Colorado</a>
