<?php

require_once("../../../wp-load.php");
global $wpdb;

$rid = $_POST['rid'];
$name = $_POST['rotator'];
$oldname = $_POST['oldname'];
$url = $_POST['url'];

	
	$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_settings SET rotator_name = '$name', default_url = '$url' WHERE id = '$rid' ";
	
		$re=$wpdb->query($sql);

	

 header('location: '.admin_url().'admin.php?page=wpurlrotator');