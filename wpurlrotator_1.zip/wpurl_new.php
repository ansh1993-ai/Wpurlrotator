<?php

$pi_path = plugins_url()."/".dirname(plugin_basename(__FILE__))."/";
$rid=$_GET['rid'];
?>


<div align="center">
<h1>Add New Link</h1>
<a href="admin.php?page=wpurlrotator&rid=<?php echo $rid; ?>">Return to Admin</a></div>
<form method="post" action="<?php echo $pi_path; ?>wpurl_donew.php?rid=<?php echo $rid; ?>" onsubmit="return formCheck()">

<div class="rTableForm" align="center">
	<div class="rTableBodyForm">
		
		<div class="rTableRowForm">
			<div class="rTableCellForm">Link Name</div>
			<div class="rTableCell"><input class="inputbox" name="name" id="name" size="50" type="text" /></div>
		</div>	
		<div class="rTableRowForm">
			<div class="rTableCellForm">Link</div>
			<div class="rTableCell"><input class="inputbox" name="url" id="url" size="75" type="text"  /></div>
			
		</div>
		<div class="rTableRowForm">		
			<div class="rTableCellForm">Weight</div>
			<div class="rTableCell"><input class="inputbox" name="weight" id="weight" size="10" type="text" value="0" /></div>
		</div>	
		<div class="rTableRowForm">
			<div class="rTableCellForm">Maximum Hits</div>
			<div class="rTableCell"><input class="inputbox" name="maxhits" id="maxhits" size="10" type="text" value="0" /></div>
		</div>
		<div class="rTableRowForm">		
			<div class="rTableCellForm">Enabled?</div>
			<div class="rTableCell">
				<input name="enabled" id="enabled" type="radio" value="Y" checked="Y">Yes 
				<input name="enabled" id="enabled" type="radio" value="N">No</div>
		</div>
		<div class="rTableRowForm">		
			<div class="rTableCellForm"> </div>
			<div class="rTableCell"><input id="EditSubmit" type="submit" value=" ADD LINK " /></div>
		</div>
	</div>
</div>
</form>

<br />
<div class="helptexttable">
<ul>
<li><span class="tbtext"><strong>Link Name</strong> is the name you want for this link. It must be unique with no spaces.</span></li>
<li><span class="tbtext"><strong>Link</strong> is the link URL beginning with http://.</span></li>
<li><span class="tbtext"><strong>Weight</strong> is the number of times you want to serve a URL before rotating to the next URL. The deault is zero. For example, if you use "5", the URL will be served 5 times before the next URL in the rotation will be served. This is optional. If you don't want to use a Weight, make sure it is set to zero.</span></li>
<li><span class="tbtext"><strong>Maximum Hits</strong> is the maximum number of hits you want delivered to a URL before it is set to Disabled. This is optional. If you don't want to use Maximum Hits, make sure it is set to zero.</span></li>
<li><span class="tbtext"><strong>Enabled</strong> Allows you to disable a URL without deleting it from the rotator.</span>
<p> </p>
</li>
</ul>
</div>

<script type="text/javascript">

function formCheck(){
                      if ($('#name').val()==""){alert('Please enter a Link Name'); return false;}
                      if ($('#url').val()==""){alert('Please enter a Link to rotate'); return false;}
                     }
</script>