<?php

global $wpdb;
require_once(ABSPATH.'wp-admin/includes/upgrade.php');

$charset_collate = $wpdb->get_charset_collate();
// setup return value

$return_value = false;

try {

	$table_name = $wpdb->prefix."wpurlrotator_links";
	
	$sql = "CREATE TABLE $table_name (
  	id int(255) NOT NULL AUTO_INCREMENT,
    camp_id varchar(64) NOT NULL,
  	next tinyint(4) NOT NULL DEFAULT 0,
  	name varchar(50) NOT NULL,
  	url varchar(200) NOT NULL,
  	cnt int(11) NOT NULL DEFAULT 0,
  	defuser varchar(12) DEFAULT NULL,
  	direct int(11) NOT NULL,
  	weight int(8) NOT NULL,
  	weight_cnt int(8) NOT NULL,
  	enabled char(4) NOT NULL,
  	maxhits int(128) NOT NULL,
  	maxhits_cnt int(11) NOT NULL,
  	UNIQUE KEY (id),
  	KEY name (name),
  	KEY enabled (enabled),
  	KEY next (next)
	) $charset_collate;";

	// dbDelta will create a new table if none exists or upgrade an existing one
	dbDelta($sql);

		    
    $sql="UPDATE $table_name SET camp_id = 1 WHERE camp_id = ''";
    $wpdb->query($sql);

	$table_name = $wpdb->prefix."wpurlrotator_count";

	$sql = "CREATE TABLE $table_name (
  	id int(255) NOT NULL AUTO_INCREMENT,
    camp_id varchar(64) NOT NULL,
    user varchar(50) NOT NULL,
  	cid varchar(64) NOT NULL,
  	date date NOT NULL DEFAULT '0000-00-00',
  	number int(11) NOT NULL DEFAULT 0,
  	ipnum varchar(20) NOT NULL,
  	ipcnt int(11) NOT NULL DEFAULT 0,
  	directip int(11) NOT NULL,
  	directhits int(32) NOT NULL,
  	country char(50) NOT NULL,
  	referredby varchar(150) NOT NULL,
  	UNIQUE KEY (id),
    KEY date (date),
  	KEY ipnum (ipnum),
  	FULLTEXT KEY user (user)
	) $charset_collate;";

	dbDelta($sql);

  $sql="UPDATE $table_name SET camp_id = 1 WHERE camp_id = ''";
    $wpdb->query($sql);

  $table_name = $wpdb->prefix."wpurlrotator_settings";
  
  $sql = "CREATE TABLE $table_name (
    id int(255) NOT NULL AUTO_INCREMENT,
    rotator_name varchar(50) NOT NULL,
    default_url varchar(200) NOT NULL,
    UNIQUE KEY (id),
    KEY rotator_name (rotator_name)
  ) $charset_collate;";

  // dbDelta will create a new table if none exists or upgrade an existing one
  dbDelta($sql);

  
	// return true
	$return_value = true;

} catch(Exception $e){
	//php error
	//echo 'Message: '.$e->getMessage();
}
// return result
return $return_value;


