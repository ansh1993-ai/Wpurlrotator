<?php
$rid = $_GET['rid'];
$get_next = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix . "wpurlrotator_settings where id = '$rid'");
	if ($get_next){
		$RotatorName = $get_next->rotator_name;
		
	}
?>
<p>
<div align="center">
	<h1><?php echo $RotatorName; ?></h1>
<p>
	<a href="admin.php?page=wpurlrotator&rid=<?php echo $rid; ?>">Return to Link Admin</a>
	<p>
</div>

<div class="rTable">

	<div class="rTableBody">
		<div class="rTableRow">
			<div class="rTableHead">Name</div>
			<div class="rTableHead">Link</div>
			<div class="rTableHead"><font color="red";>Weight Count</font></div>
			<div class="rTableHead">Reset Weight Count</div>
			<div class="rTableHead"><font color="red";>Max Hits Count</font></div>
			<div class="rTableHead">Reset Max Hits Count</div>
		</div>


		<?php
		
 		$re = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."wpurlrotator_links WHERE camp_id = '$rid' ORDER BY id ASC" );

 		
 		// $wpdb->query( $sql );
  		foreach ( $re as $ro ){

		  	if($ChangeColor == 0){
				$bgcolor = "#eaeaea" ;
				$ChangeColor = 1;
			} else {
				$bgcolor = "#FFFFFF" ;
				$ChangeColor = 0;
			}


			$id = $ro->id;
			$name = $ro->name;
			$url = $ro->url;
			$next = $ro->next;
			$weight = $ro->weight;
			$weight_cnt = $ro->weight_cnt;
			$maxhits = $ro->maxhits;
			$maxhits_cnt = $ro->maxhits_cnt;

			if ($next == '1') {
  				$url = "<a href=".$url." target=_blank><b><i>".$url."</i></b></a>";
  				$name = "<b><i>".$name."</i></b>";
			} else {
				$url = "<a href=".$url." target=_blank>".$url."</a>";
 				$name = $name;
			}
			
			?>
			<div class="rTableRow">
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><?php echo $name; ?></div>
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><?php echo $url; ?></div>
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><font color="red"><?php echo $weight_cnt; ?></font> of <?php echo $weight; ?></div>
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><a href="admin.php?page=wpurlrotator&a=rwm&type=w&l=<?php echo $id; ?>&rid=<?php echo $rid; ?>">Reset Weight Counts</a></div>
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><font color="red"><?php echo $maxhits_cnt; ?></font> of <?php echo $maxhits; ?></div>
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><a href="admin.php?page=wpurlrotator&a=rwm&type=m&l=<?php echo $id; ?>&rid=<?php echo $rid; ?>">Reset Max Hits Counts</a></div>
			</div>	
			<?php

		}	

?>

	</div>
</div>		