<?php


$id = $_GET['l'];
$rid = $_POST['rid'];
$type = $_GET['type'];

if ($type == 'w') {
   	$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_links SET weight_cnt = 0 Where id = '$id' ";
	$re=$wpdb->query($sql);
}

if ($type == 'm') {
   	$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_links SET maxhits_cnt = 0 Where id = '$id' ";
	$re=$wpdb->query($sql);
}

include ("wpurl_reset_counts.php");
//header('location: '.admin_url().'admin.php?page=wpurlrotator&a=rs&rid='.$rid);