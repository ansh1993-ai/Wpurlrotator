<?php

add_shortcode( 'wpurlmember' , 'wpurl_shortcode' );

function wpurl_shortcode($atts, $content){
	
global $wpdb;


$wpurl_member_id  = get_query_var('memid');

//echo "This is mid ".$wpurl_member_id;
$rowresults = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."wpurlrotator_links where id = ".$wpurl_member_id); 

$results = $wpdb->get_results("SELECT user, date, country, sum(number) AS number, sum(ipcnt) AS ipcnt FROM ".$wpdb->prefix."wpurlrotator_count where cid = ".$wpurl_member_id." GROUP BY date, country ORDER BY date DESC "); 

$results1 = $wpdb->get_results("SELECT user, date, ipnum, sum(number) AS number, sum(ipcnt) AS ipcnt, country, referredby FROM ".$wpdb->prefix."wpurlrotator_count where cid = ".$wpurl_member_id." GROUP BY date, ipnum, referredby ORDER BY date DESC"); 

$content = '<b>Summary of Hits Delivered</b><table>
			<tr>
				<th>Name</th>
				<th>Destination URL</th>
				<th>Count</th>
			</tr>';


//foreach($results as $k=>$i){

$content .= '<tr>
                  <td> '.$rowresults->name.' </td>
                  <td> '.$rowresults->url.' </td>
				  <td> '.$rowresults->cnt.' </td>
                  
          </tr>';

		  
//}
$content .= '</table>';

$content .= '<b>Hits By Country</b><table>
				<tr>
					<th>Date</th>
					<th>Country</th>
					<th>Hits</th>
					<th>Unique Hits</th>
					
				</tr>';
			
foreach($results as $k=>$i){
	$content .= '
	<tr>
                  <td> '.$i->date.' </td>
				  <td> '.$i->country.' </td>
                  <td> '.$i->number.' </td>
				  <td> '.$i->ipcnt.' </td>
                  
          </tr>';
	
	
}
$content .= '</table><b>Hits By Referring URL</b>';

$content .= '<table>
				<tr>
					
					<th>Date</th>
					<th>Referring URL</th>
					<th>Hits</th>
					<th>Unique Hits</th>
									
					
				</tr>';
			
foreach($results1 as $k=>$i){
	$content .= '
	<tr>
                 
                  <td> '.$i->date.' </td>
				   <td> '.$i->referredby.' </td>
				  <td> '.$i->number.' </td>
				  <td> '.$i->ipcnt.' </td>
				 
                  
          </tr>';
	
	
}
$content .= '</table>';

return $content;


}
