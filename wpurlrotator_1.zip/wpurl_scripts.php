<?php

// Add Scripts

function wpurlrotator_add_scripts(){
	wp_enqueue_style('wpurlrotator-main-style',plugins_url().'/'.dirname(plugin_basename(__FILE__)).'/css/style.css');
	//wp_enqueue_script('PREFIX-main-script',plugins_url().'/wpurlrotator/js/main.js');

}

add_action('admin_init','wpurlrotator_add_scripts');



