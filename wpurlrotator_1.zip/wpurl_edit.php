<?php

$rid = $_GET['rid'];
$id=$_GET['l'];
$pi_path = plugins_url()."/".dirname(plugin_basename(__FILE__))."/";

$get_item = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix . "wpurlrotator_links WHERE camp_id = '$rid' and id ='$id' ");

if ($get_item){
			$id = $get_item->id;
			$name = $get_item->name;
			$oldname = $get_item->name;
			$url = $get_item->url;
			$weight = $get_item->weight;
			$enabled = $get_item->enabled;
			$oldenabled = $get_item->enabled;
			$maxhits = $get_item->maxhits;
			$next = $get_item->next;

		}

?>
	

<div align="center">
<h1><?php echo $iname; ?></h1>
<a href="admin.php?page=wpurlrotator&rid=<?php echo $rid; ?>">Return to Rotator Admin</a></div>
<form method="post" action="<?php echo $pi_path; ?>wpurl_doedit.php" onsubmit="return formCheck()">
<input type="hidden" name="id" value="<?php echo $id; ?>">
<input type="hidden" name="rid" value="<?php echo $rid; ?>">
<input type="hidden" name="oldname" value="<?php echo $oldname; ?>">
<input type="hidden" name="oldenabled" value="<?php echo $oldenabled; ?>">
<input type="hidden" name="next" value="<?php echo $next; ?>">
<div class="rTableForm" align="center">
	<div class="rTableBodyForm">
		
		<div class="rTableRowForm">
			<div class="rTableCellForm">Link Name</div>
			<div class="rTableCell"><input class="inputbox" name="name" id="name" size="50" type="text" value="<?php echo $name; ?>" /></div>
		</div>	
		<div class="rTableRowForm">
			<div class="rTableCellForm">Link</div>
			<div class="rTableCell"><input class="inputbox" name="url" id="url" size="75" type="text" value="<?php echo stripslashes($url); ?>" /></div>
			
		</div>
		<div class="rTableRowForm">		
			<div class="rTableCellForm">Weight</div>
			<div class="rTableCell"><input class="inputbox" name="weight" id="weight" size="10" type="text" value="<?php echo $weight; ?>" /></div>
		</div>	
		<div class="rTableRowForm">
			<div class="rTableCellForm">Maximum Hits</div>
			<div class="rTableCell"><input class="inputbox" name="maxhits" id="maxhits" size="10" type="text" value="<?php echo $maxhits; ?>" /></div>
		</div>
		<div class="rTableRowForm">		
			<div class="rTableCellForm">Enabled?</div>
			<div class="rTableCell">
				<input name="enabled" id="enabled" type="radio" value="Y" <?php if($enabled == 'Y') echo 'checked';  ?> />Yes 
				<input name="enabled" id="enabled" type="radio" value="N" <?php if($enabled == 'N') echo 'checked';  ?> />No</div>
		</div>
		<div class="rTableRowForm">		
			<div class="rTableCellForm"> </div>
			<div class="rTableCell"><input id="EditSubmit" type="submit" value=" EDIT LINK " /></div>
		</div>
	</div>
</div>
</form>

<br />
<div class="helptexttable">
<ul>
<li><span class="tbtext"><strong>Link Name</strong> is the name you want for this link. It must be unique with no spaces.</span></li>
<li><span class="tbtext"><strong>Link</strong> is the link URL beginning with http://.</span></li>
<li><span class="tbtext"><strong>Weight</strong> is the number of times you want to serve a URL before rotating to the next URL. The deault is zero. For example, if you use "5", the URL will be served 5 times before the next URL in the rotation will be served. This is optional. If you don't want to use a Weight, make sure it is set to zero.</span></li>
<li><span class="tbtext"><strong>Maximum Hits</strong> is the maximum number of hits you want delivered to a URL before it is set to Disabled. This is optional. If you don't want to use Maximum Hits, make sure it is set to zero.</span></li>
<li><span class="tbtext"><strong>Enabled</strong> Allows you to disable a URL without deleting it from the rotator.</span>
<p> </p>
</li>
</ul>
</div>

<script type="text/javascript">

function formCheck(){
                      if ($('#name').val()==""){alert('Please enter a Link Name'); return false;}
                      if ($('#url').val()==""){alert('Please enter a Link to rotate'); return false;}
                     }
</script>