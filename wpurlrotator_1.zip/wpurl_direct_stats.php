<?php


$id=$_GET['l'];
$rid=$_GET['rid'];
$pi_path = plugins_url()."/".dirname(plugin_basename(__FILE__))."/";

?>

<div align="center">
<h1><?php echo $iname; ?></h1>
<a href="admin.php?page=wpurlrotator&rid=<?php echo $rid; ?>">Return to Admin</a></div>

<div class="sTable">

	<div class="rTableBody">
		<div class="rTableRow">
			<div class="rTableHead">Link Name</div>
			<div class="rTableHead">Date</div>
			<div class="rTableHead">Direct Hits</div>
			<div class="rTableHead">Unique Direct Hits</div>
			<div class="rTableHead">Detail</div>
		</div>

		<?php

 		$re = $wpdb->get_results( "SELECT user, date, sum(directhits) AS number, sum(directip) AS ipcnt FROM ".$wpdb->prefix."wpurlrotator_count WHERE cid = $id GROUP BY user, date ORDER BY date DESC " );

 		
 		// $wpdb->query( $sql );
  		foreach ( $re as $ro ){

		  	if($ChangeColor == 0){
				$bgcolor = "#eaeaea" ;
				$ChangeColor = 1;
			} else {
				$bgcolor = "#FFFFFF" ;
				$ChangeColor = 0;
			}


			//$id = $ro->id;
			$name = $ro->user;
			$date = $ro->date;
			$cnt = $ro->number;
			$direct = $ro->ipcnt;
			
			?>
			<div class="rTableRow">
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><?php echo $name; ?></div>
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><?php echo $date; ?></div>
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><?php echo $cnt; ?></div>
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><?php echo $direct; ?></div>
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><a href="admin.php?page=wpurlrotator&a=dld&l=<?php echo $id; ?>">Detail</a></div>
			</div>	
			<?php

		}	

?>

	</div>
</div>

