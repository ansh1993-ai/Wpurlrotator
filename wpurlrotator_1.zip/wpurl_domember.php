<?php

require_once("../../../wp-load.php");
//global $wpdb;

$name = $_POST['name'];

$option_exists = get_option("wpurl_member_page");

if (!option_exists) {
add_option("wpurl_member_page", $name, '', 'yes');
} else {
	update_option("wpurl_member_page", $name);
}
//echo "this is name ".$name;

header('location: '.admin_url().'admin.php?page=wpurlrotator');

