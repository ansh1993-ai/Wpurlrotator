<?php
require_once("../../../wp-load.php");
global $wpdb;

$id = $_GET['l'];
$rid = $_GET['rid'];
//echo "this is rid ".$rid;

$sql="DELETE FROM ".$wpdb->prefix."wpurlrotator_count WHERE cid ='$id'";
 
$wpdb->query( $sql );

$sql="DELETE FROM ".$wpdb->prefix."wpurlrotator_links WHERE id ='$id'";
 
 $wpdb->query( $sql );

 header('location: '.admin_url().'admin.php?page=wpurlrotator&rid='.$rid);