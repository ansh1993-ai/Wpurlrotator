<?php

 
$baseurl = site_url();
$rid=$_GET['rid'];
//echo "This is id ".$camp_id;

$today = date('Y-m-d');

// Get Rotator Name
$get_next = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix . "wpurlrotator_settings WHERE id = '$rid' ");
	if ($get_next){
		$RotatorName = $get_next->rotator_name;
		$DefaultURL = $get_next->default_url;
	

if ($sort == "")
	{
	$querysort = "id";
	} else 
		{
		switch ($sort)
		{
			case 'sn':
			$querysort ="name";
		break;
			case 'su':
			$querysort ="url";
		break;
			case 'se':
			$querysort ="enabled";
		break;	
		}
	}
	
$sortorder = "ASC";
$sortheading = "Asc";
$sorder = "a";

if ($order == "d")
	{
		$sortorder = "DESC";
		$sortheading = "Asc";
		$sorder = "a";
	}
if ($order == "a")
	{
		$sortorder = "ASC";
		$sortheading = "Desc";
		$sorder = "d";
	}
	
	?>


<center>
	<p>
<p>
<h1><?php echo $RotatorName; ?> Link Rotator</H1>
<P>
<P><h3><b><?php echo $RotatorName; ?> Rotator Link: <a href="<?php echo $baseurl; ?>/<?php echo $RotatorName; ?>/" target="_blank"><?php echo $baseurl; ?>/<?php echo $RotatorName; ?>/</a></b></h3>
<p>
<P>
<a href="admin.php?page=wpurlrotator&a=n&rid=<?php echo $rid; ?>">Add New Link</a>    |    <a href="admin.php?page=wpurlrotator&a=bl&rid=<?php echo $rid; ?>">Add A Batch of Links </a>    |    
<a href="admin.php?page=wpurlrotator&a=dl&rid=<?php echo $rid; ?>">Get Direct Links</a>     |    
<a href="admin.php?page=wpurlrotator&a=rs&rid=<?php echo $rid; ?>">Reset Weight & Maxhits Counts</a>    |    
<a href="admin.php?page=wpurlrotator&a=r&t=e&rid=<?php echo $rid; ?>">Reset All Enabled Stats</a>    |    
<a href="admin.php?page=wpurlrotator&a=r&t=d&rid=<?php echo $rid; ?>">Reset All Disabled Stats</a>    |    
<a href="admin.php?page=wpurlrotator&a=ml&rid=<?php echo $rid; ?>" >Get Member Stats Links</a>    |    
<a href="admin.php?page=wpurlrotator&a=h" >Link Admin Help</a>

<P>
<div>	
<form name='batch' action='admin.php?page=wpurlrotator&a=b&rid=<?php echo $rid; ?>' method='post' enctype='multipart/form-data' >	
<div align='left'>
<select name='batchAction'>
  <option value=''>Select...</option>
  <option value='D'>Disable</option>
  <option value='E'>Enable</option>
  <option value='R'>Reset Stats</option>
  <option value='Del'>Delete Link</option>
</select>
<input type='submit' name='submit' value=' Perform Action '  class='inputbox'>

</div>
<div class="rTable">

	<div class="rTableBody">
		<div class="rTableRow">
			<div class="rTableHead">Select</div>
			<div class="rTableHead">Edit </div>
			<div class="rTableHead">Reset </div>
			<div class="rTableHead">Name</div>
			<div class="rTableHead">Link</div>
			<div class="rTableHead">Weight</div>
			<div class="rTableHead">Enabled</div>
			<div class="rTableHead">Max Hits</div>
			<div class="rTableHead">Rotate Hits</div>
			<div class="rTableHead">Rotate Unique</div>
			<div class="rTableHead">Direct Hits</div>
			<div class="rTableHead">Direct Unique</div>
			<div class="rTableHead">Delete</div>
		</div>



<?php

 $re = $wpdb->get_results( " SELECT * FROM ".$wpdb->prefix."wpurlrotator_links WHERE camp_id = '$rid' ORDER BY id ASC" );
 // $wpdb->query( $sql );
  foreach ( $re as $ro ){

  	if($ChangeColor == 0)
		{
			$bgcolor = "#eaeaea" ;
			$ChangeColor = 1;
		}
		else
		{
			$bgcolor = "#FFFFFF" ;
			$ChangeColor = 0;
		}


$id = $ro->id;
$name = $ro->name;
$url = $ro->url;
$cnt = $ro->cnt;
$direct = $ro->direct;
$weight = $ro->weight;
$weight_cnt = $ro->weight_cnt;
$next = $ro->next;
$enabled = $ro->enabled;
$maxhits = $ro->maxhits;
$maxhits_cnt = $ro->maxhits_cnt;

if ($next == 1) {
  $durl = "<b><i>".$url."</i></b>";
  $dname = "<b><i>".$name."</i></b>";
} else {
 $durl = "<a href=".$url." target=_blank>".$url."";
 $dname = $name;
}
//$rotip = $wpdb->get_row ("select count(distinct(ipnum)) as uip from ".$wpdb->prefix."wpurlrotator_count where cid = '$cid' and ipcnt = 1");
$rotip = $wpdb->get_row ("select count(distinct(ipnum)) as uip from ".$wpdb->prefix."wpurlrotator_count where cid = '$id'");
//$rotip = $db->get_a_line("select count(distinct(ipnum)) as uip from counts where user = '$name' and ipcnt = 1") ;
$uip = $rotip->uip;

$dirip =  $wpdb->get_row("select count(distinct(ipnum)) as Cnt, Sum(directhits) as dirhits from ".$wpdb->prefix."wpurlrotator_count where cid = '$id' and directip = 1") ;
$directip = $dirip->Cnt;
$dircnt = $dirip->dirhits;
?>
		<div class="rTableRow">
			<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<input type='checkbox' name='bid[]' id='bid' value='<?php echo $id; ?>'>
      		</div>
			<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<a href='admin.php?page=wpurlrotator&a=e&rid=<?php echo $rid; ?>&l=<?php echo $id; ?>'>Edit</a>
      		</div>
      		<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<a href='admin.php?page=wpurlrotator&a=r&rid=<?php echo $rid; ?>&l=<?php echo $id; ?>'>Reset</a>
      		</div>
      		<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<div><?php echo $dname; ?></div>
      		</div>
      		<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<div><a href="<?php echo $url; ?>" ><?php echo $durl; ?></a></div>
      		</div>
      		<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<div><?php echo $weight_cnt; ?> of <?php echo $weight; ?></div>
      		</div>
      		<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<div><?php echo $enabled; ?></div>
      		</div>
      		<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<div><?php echo $maxhits_cnt; ?> of <?php echo $maxhits; ?></div>
      		</div>
      		<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<div><a href='admin.php?page=wpurlrotator&a=s&rid=<?php echo $rid; ?>&l=<?php echo $id; ?>'><?php echo $cnt; ?></a></div>
      		</div>
       		<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<div><?php echo $uip; ?></div>
      		</div>
      		<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<div><a href='admin.php?page=wpurlrotator&a=dls&rid=<?php echo $rid; ?>&l=<?php echo $id; ?>'><?php echo $direct; ?></a></div>
      		</div>
      		<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<div><?php echo $directip; ?></div>
      		</div>
      		<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<div><a href="#" onclick="confirmDelete(<?php echo $id; ?>,<?php echo $rid; ?>)">Delete</a>
				</div>
      		</div>

  		</div>
	 

<?php
}
?>
	</div>
</div>
</form>
<script type='text/javascript'>
function confirmDelete(ID,RID){
                         var c=confirm('Are you sure you want to delete this link, and all tracking data?');
                         if (c){
                                window.location='<?php echo $pi_path; ?>wpurl_delete.php?l='+ID+'&rid='+RID;
                               }
                        }
</script> 
<?php 
} else {
	
	//header('location:admin.php?page=wpurlrotator');
}