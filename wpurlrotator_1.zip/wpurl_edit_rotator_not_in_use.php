<?php

$id=$_GET['l'];
$pi_path = plugins_url()."/wpurlrotator/";

$get_item = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix . "wpurlrotator_settings WHERE id ='$id' ");

if ($get_item){
		$id = $get_item->id;
		$RotatorName = $get_item->rotator_name;
		$DefaultURL = $get_item->default_url;
	}

?>
	

<div align="center">
	<h1><?php echo $RotatorName; ?></h1>
	<a href="admin.php?page=wpurl_settings">Return to Rotator Settings</a>
</div>
<form method="post" action="<?php echo $pi_path; ?>wpurl_doedit_rotator.php" onsubmit="return formCheck1()">
<input type="hidden" name="id" value="<?php echo $id; ?>">
<input type="hidden" name="oldname" value="<?php echo $oldname; ?>">

<div class="rTableForm" align="center">
	<div class="rTableBodyForm">
		<div class="rTableRowForm">
			<div class="rTableCellForm">Rotator Name</div>
			<div class="rTableCell"><input class="inputbox" name="name" id="name" size="50" type="text" value="<?php echo $RotatorName; ?>" /></div>
		</div>	
		<div class="rTableRowForm">
			<div class="rTableCellForm">Default URL</div>
			<div class="rTableCell"><input class="inputbox" name="url" id="iurl" size="75" type="text" value="<?php echo stripslashes($DefaultURL); ?>" /></div>
		</div>
		<div class="rTableRowForm">		
			<div class="rTableCellForm"> </div>
			<div class="rTableCell"><input id="EditSubmit" type="submit" value=" EDIT LINK " /></div>
		</div>
	</div>
</div>

</form>

<br />
<div class="helptexttable">
<ul>
<li><span class="tbtext"><strong>Rotator Name</strong> is the name you want for your rotator. It must be unique, meaning you have no other Posts or Pages 
	with the same name. It must also have no spaces, or special characters other than "-". 
	<p class="tbtext">You can use somthing as simple as "rotator" or something as vague as
some random text or numbers so people don't know you are using a rotator. 
<p class="tbtext">It is highly recommended that you choose a name that you will never change. Otherwise,
you may have links out there that point to that specific URL based on your rotator name. This Rotator Name will be the last part of your URL.</span></li>
<li><span class="tbtext"><strong>Default URL</strong> is the link URL beginning with http:// that you would like traffic directed to in the event that all of your 
	links in the rotator become disabled, or in the rare event that your rotator can't find the next URL to serve.</span></li>

<p> </p>
</li>
</ul>
</div>

<script type="text/javascript">

function formCheck1(){
                      if ($('#name').val()==""){alert('Please enter a Link Name'); return false;}
                      if ($('#url').val()==""){alert('Please enter a Link to rotate'); return false;}
                     }
</script>