<?php

global $wpdb;

$do_this = $_GET['do'];
$rid=$_GET['rid'];
$exists = $_GET['exists'];
$baseurl = site_url();
$pi_path = plugins_url()."/".dirname(plugin_basename(__FILE__))."/";
$rotator = $_GET['name'];

if ($exists == 'y'){
	$already_exists = "<font color = 'red'><b>".$rotator." - Rotator already exits, choose another name.</font></b>";
	$exists = '';
}

//echo "<center>This is do this".$do_this;
	if ($do_this == 'new'){
		echo "<h1>Add New Rotator</H1>";
		$submit_button = "ADD Rotator";
	} else {
		if ($do_this == 'edit'){
			echo "<h1>Edit Rotator</H1>";
			$submit_button = "Save Rotator";
			$get_rotator = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix . "wpurlrotator_settings WHERE id ='$rid' ");

			if ($get_rotator){	
				$rid = $get_rotator->id;
				$rotator = $get_rotator->rotator_name;
				$def_url = $get_rotator->default_url;
				$oldname = $rotator;
				
			}
		}	
	}	
?>	
	<P>
	<P><a href="admin.php?page=wpurlrotator">Close</a>
</center>

	<form method="post" action="<?php echo $pi_path; ?>wpurl_dosettings.php?rid=<?php echo $rid; ?>&do=<?echo $do_this; ?>" onsubmit="return formCheckRot()">
	<input type="hidden" name="oldname" value="<?php echo $oldname; ?>">
	<div class="rTableForm" align="center">
		<div class="rTableBodyForm">
		
		<div class="rTableRowForm">
			<div class="rTableCellForm">Rotator Name</div>
			<div class="rTableCell"><input class="inputbox" name="rotator" id="rotator" value="<?php echo $rotator; ?>" size="50" type="text" />  <?php echo $already_exists; ?></div>
		</div>	
		<div class="rTableRowForm">
			<div class="rTableCellForm">Default Link</div>
			<div class="rTableCell"><input class="inputbox" name="url" id="url" value="<?php echo $def_url; ?>" size="75" type="text"  /></div>
			
		</div>
		<div class="rTableRowForm">		
			<div class="rTableCellForm"> </div>
			<div class="rTableCell"><input id="NewSubmit" type="submit" value=" <?php echo $submit_button; ?>"  /></div>
		</div>
	</div>
</div>
</form>





<center>


<div class="helptexttable">
<ul>
<li><span class="tbtext"><strong>Rotator Name</strong> is the name you want for your rotator. It must be unique, meaning you have no other Posts or Pages 
	with the same name. It must also have no spaces, or special characters other than "-". 
	<p class="tbtext">
	In addition a rotator called "Rotator" is the same as one called "rotator". Only one with the name "rotator" is allowed, regardless of case. 
	Case is ignored when referencing a web page - http://mysite.com/rotator is the same as http://mysite.com/Rotator. So rotator names must also be unique
	regardless of upper or lower case.
	<p class="tbtext">You can use somthing as simple as "rotator" or something as vague as
some random text or numbers so people don't know you are using a rotator. 
<p class="tbtext">It is highly recommended that you choose a name that you will never change. Otherwise,
you may have links out there that point to that specific URL based on your rotator name. This Rotator Name will be the last part of your URL.</span></li>
<li><span class="tbtext"><strong>Default URL</strong> is the link URL beginning with http:// that you would like traffic directed to in the event that all of your 
	links in the rotator become disabled, or in the rare event that your rotator can't find the next URL to serve.</span></li>

<p> </p>
</li>
</ul>
</div>

<script type='text/javascript'>

var $ = jQuery.noConflict();
	function formCheckRot(){
                      if ($('#rotator').val()==""){alert('Please enter a Rotator Name'); return false;}
                      if ($('#url').val()==""){alert('Please enter a Default Link'); return false;}
                     } 

                    
                     
</script>