<center>
	<p>
<a href="admin.php?page=wpurlrotator">Return to Admin</a>
<div class="helpTable">
	

<b><h2>Admin Help:</h2></b>
<p>
<b>Add New Link</b> - Allow you to add new links to your rotator/count tracker.
<P>
<b>Add A Batch of Links</b> - Instead of adding links one at a time, you can add a number of links all at once.
<p>	
<b>Get Direct Links</b> - If you want to track the number of hits to a specific URL, you can get the direct linking URL for all links in the table by clicking on this link.  Then you use this direct link URL in your advertising campaigns.  You can have the same URL in a rotation campaign and be direct linking to it at the same time.
<p>
<b>Reset Weight & Maxhits Counts</b> - Allows you to reset the current Weight and Max Hits counts to zero.  
<p>
<b>Reset All Enabled Stats</b> - This will reset all hit stats to zero for all links that are Enabled. This is useful if you want a fresh start in your stats data collection. Instead of having to reset stats for each link, or select each link and then reset, it allows you to reset all Enabled links at once.
<p>
<b>Reset All Disabled Stats</b> - This will reset all hit stats to zero for all links that are Disabled. This is useful if you want a fresh start in your stats data collection. Instead of having to reset stats for each link, or select each link and then reset, it allows you to reset all Disabled links at once.

<P>

<b>Help</b> - The Help Page you are now viewing:)
<P>
<b><h2>Table Columns:</h2></b>
<P>
<b>Edit</b> - Allows you to edit the link name or the link URL for the link in that row.
<P>
<b>Reset Count</b> - Reset the Rotator Counts and Direct Counts data to zero for the link in that row.
<P>
<b>Name</b> - Name of the link in the rotator.  The next link to be rotated is listed in <b><i>Bold and Italics.</i></b>
<P>
<b>Link</b> - URL of the link in the rotator.  You can click on the link to verify the link is correct and goes where you want it to go. The next link to be rotated is listed in <b><i>Bold and Italics.</i></b>
<P>
<b>Weight</b> - is the number of times you want to serve a URL before rotating to the next URL. The default is zero.  For example - if you use 5 the URL will be served 5 times before the next URL in the rotation will be served. This column shows where the rotator is in the current weight.
<P>
<b>Enabled</b> - Allows you to disable a URL without deleting it from the rotator.  Also, a URL will also be disabled if a URL hits it's MaxHits setting.
<P>
<b>Maximum Hits</b> - The maximum number of hits you want delivered to a URL before it is set to Disabled. This is optional. If you don't want to use Maximum Hits, make sure it is set to zero. 
<P>
<b>Rotate Hits</b> -  Total number of hits for the URL in that row.  Clicking on the Rotate Hits number for the row, will display hit details for that URL.  Clicking on the Rotate Hits column heading will display the details for all of the URL's in the rotator. 
<P>

<b>Rotate Unique</b> - The number of actual unique hits for that rotator row.  This is a count of the unique hits by IP address.  Clicking on the Rotate Unique number for the row, will display unique hit details for that URL.  Clicking on the Rotate Unique column heading will display the details for all of the URL's in the rotator. 
<P>
<b>Direct Hits</b> - Total number of hits sent directly to the URL in that row, instead of hits via the rotator.  Clicking on the Direct Hits number for the row, will display direct hit details for that URL.  Clicking on the Direct Hits column heading will display the direct hit details for all of the URL's. 
<P>
<b>Direct Unique</b> - Total number of unique hits sent directly to the URL in that row, instead of hits via the rotator.  Clicking on the Direct Unique number for the row, will display unique direct hit details for that URL.  Clicking on the Direct Unique column heading will display the direct hit details for all of the URL's. 
<P>
<b>Delete</b> - Delete the URL in that row.  This will delete the direct link URL and the rotate URL, plus all hits related to that link.
</div>

</center>