<?php

$rid = $_GET['rid'];
//echo "this is rid ".$rid;
$baseurl = site_url();

$get_next = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix . "wpurlrotator_settings where id = '$rid'");
	if ($get_next){
		$RotatorName = $get_next->rotator_name;
		$DefaultURL = $get_next->default_url;
	}
$MemberPageName = get_option("wpurl_member_page");
?>
<div align='center'>
	<h1><? echo $RotatorName; ?></h1>
	<p>
	<a href='admin.php?page=wpurlrotator&rid=".$rid."'>Close Member Stats Links</a>
</div>
<?php
if (!$MemberPageName) {
	echo "<div class='helptexttable'>
	
	<span class='tbtext'>If you want members to be able to see the hits that have been sent to their URL, we need to create a short code on a page for them to be able to see their stats.
	<p class='tbtext'>You will need to:<br>
	1. Create a PAGE with a name that will make sense, like MemberStats. I suggest using a page with no spaces to make it easier for you.<br/>
	2. Place this short cold in the page - [wpurlmember]<br />
	3. <a href='admin.php?page=wpurlrotator&a=ms'>Go Here</a> and place the page name in the form.
	<p class='tbtext'>
	We will then be able to form a unique URL for each link that you can give to your members. They will only see their stats because of each unique URL.
	<p class='tbtext'>Important Note: We're only asking for this page name so we can setup the Member Stats URL for you. 


</div>";
} else {
echo "	
<div class='sTable'>

	<div class='rTableBody'>
		<div class='rTableRow'>
			<div class='rTableHead'>Link/Member Name</div>
			<div class='rTableHead'>Member Stats URL</div>

		</div>";

		

 		$re = $wpdb->get_results( "SELECT id, name, url, camp_id FROM ".$wpdb->prefix."wpurlrotator_links WHERE camp_id = '$rid'" );

 		
 		// $wpdb->query( $sql );
  		foreach ( $re as $ro ){

		  	if($ChangeColor == 0){
				$bgcolor = "#eaeaea" ;
				$ChangeColor = 1;
			} else {
				$bgcolor = "#FFFFFF" ;
				$ChangeColor = 0;
			}


			$id = $ro->id;
			$name = $ro->name;
			$url = $ro->url;
			$camp_id = $ro->camp_id;
			$url = $baseurl."/".$MemberPageName."?memid=".$id;
			
			echo "<div class='rTableRow'>
				<div class='rTableCell' background-color='".$bgcolor."'>".$name."</div>
				<div class='rTableCell' background-color='".$bgcolor."'><a href='".$url."' target='_blank'>".$url."</a></div>

			</div>	"; 
			

		}	
	}


?>
	</div>
</div>

