<?PHP
/**
* Plugin Name: WP URL Rotator
* Description: Rotate Unlimited Links, in Unlimited Campaigns, of Your Favorite Affiliate Product or MLM Programs
* Version: 2.5
* Author: Mike in Colorado
*
**/

// Exit if Accessed Directly
if(!defined('ABSPATH')) {
	exit;
}


add_action ('wp', 'hbr_get_next_link');
function hbr_get_next_link (){
	global $wpdb;
	global $post;
	$id=$_GET['l'];
$wpurl_member_id  = get_permalink();

	$Request_URL = site_url();
	$Request_URL = str_replace('http://', '', $Request_URL);
	$Request_URL = str_replace('https://', '', $Request_URL);
	$Request_URL = str_replace('www', '', $Request_URL);
	$Root_URL=$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];

	$Extracted = str_replace($Request_URL,'',$Root_URL);
	$Extracted = str_replace('www','',$Extracted);
	$ExtractedID = $Extracted;
	$Extracted = str_replace('/','',$Extracted);
	$ExtractedID = substr($ExtractedID, strrpos($ExtractedID,'/')+1, strlen($ExtractedID));
	$Extracted = str_replace($ExtractedID, '', $Extracted);
	$ExtractedID = str_replace('?','',$ExtractedID);
	
	//echo "<br>this is extracted ".$Extracted;
	//$ExtractedID = str_replace($RotatorName,'',$Extracted);
	//echo "<br>this is extracted id ".$ExtractedID;

	// Get the rotator name and default URL
	$get_next = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix . "wpurlrotator_settings WHERE rotator_name = '".$Extracted."' ");
	if ($get_next){
		$RotatorName = $get_next->rotator_name;
		$DefaultURL = $get_next->default_url;
		$Rid = $get_next->id;
	
	if (!$ExtractedID) {
		$get_next = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix . "wpurlrotator_links WHERE camp_id = '".$Rid."' and next ='1' ");
		$get_first_enabled = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix . "wpurlrotator_links WHERE camp_id = '".$Rid."' and enabled ='Y' LIMIT 1 ");

		if ($get_next){
			$CurrURL = $get_next->url;
			$CurrID = $get_next->id;
			$CurrName = $get_next->name;
			$Currcnt = $get_next->cnt;
			$Currcnt ++;
			$Currweight = $get_next->weight;
			$Currweight_cnt = $get_next->weight_cnt;
			$Currmaxhits = $get_next->maxhits;
			$Currmaxhits_cnt = $get_next->maxhits_cnt;
			$Currnext = $get_next->next;
//echo "<br> this is Rid ".$Rid;
			// Get referring info
			$pip = $_SERVER['REMOTE_ADDR'];
			$referredby = $_SERVER['HTTP_REFERER'];


			header('location:'.$CurrURL);
 			include ("wpurl_update_tables.php");

			exit();

		} elseif ($get_first_enabled) {
			//echo "No next URL found, but an enabled URL is found";
			$CurrURL = $get_first_enabled->url;
			$CurrID = $get_first_enabled->id;
			$CurrName = $get_first_enabled->name;
			$Currcnt = $get_first_enabled->cnt;
			$Currcnt ++;
			$Currweight = $get_first_enabled->weight;
			$Currweight_cnt = $get_first_enabled->weight_cnt;
			$Currmaxhits = $get_first_enabled->maxhits;
			$Currmaxhits_cnt = $get_first_enabled->maxhits_cnt;
			$Currnext = $get_first_enabled->next;

			// Get referring info
			$pip = $_SERVER['REMOTE_ADDR'];
			$referredby = $_SERVER['HTTP_REFERER'];


			header('location:'.$CurrURL);
 			include ("wpurl_update_tables.php");
			
			exit();
					

		} else {
			header('location:'.$DefaultURL);
			//echo "No next URL found, will redirect to default URL";
		}

	} else {

		// A Direct Link
		if ($ExtractedID !='0') {
			//echo "<br>This is extracted if it is > 0: ".$Extracted."<br> This is RotatorName ".$RotatorName.$ExtractedID;
			$get_next = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix . "wpurlrotator_links WHERE camp_id = '".$Rid."' and id ='".$ExtractedID."' ");
			if ($get_next){
				$CurrURL = $get_next->url;
				$CurrID = $get_next->id;
				$CurrCamp_ID = $get_next->camp_id;
				$CurrName = $get_next->name;
				$Currdirect = $get_next->direct;
				$Currdirect ++;
				// Get referring info
				$pip = $_SERVER['REMOTE_ADDR'];
				$referredby = $_SERVER['HTTP_REFERER'];

				header('location:'.$CurrURL);
 				include ("wpurl_update_direct_tables.php");

				
			} else {
				// No or Wrong  Dircect Link URL
				header('location:'.$DefaultURL);
			}

			
		} 

	}
} else {
	//echo "YOu must create a rotator first";
}

}


register_activation_hook(__FILE__,'wpurlrotator_install');

function wpurlrotator_install() {
                                     
        include('wpurl_create_tables.php');

        }

if ( is_admin() ){

	require_once(plugin_dir_path(__FILE__).'wpurl_scripts.php');


 // Create Menu Item
	function wpurlrotator_admin_menu() {

    		add_menu_page('WP URL Rotator', 'WP URL Rotator', 'administrator','wpurlrotator', 'wpurlrotator_admin');
    		//add_submenu_page('wpurlrotator', 'Settings', 'Settings', 0, 'wpurlrotator_settings', 'wpurlrotator_settings');
    		
	}

	add_action('admin_menu', 'wpurlrotator_admin_menu');
}

function wpurlrotator_admin(){
	//Echo 'this is my admin page for now';
	global $wpdb;
	 $pi_path = plugins_url()."/".dirname(plugin_basename(__FILE__))."/";
	//include('/includes/hbr-admin.php');

	wp_enqueue_script('wpurlrotator-main-script','//ajax.googleapis.com/ajax/libs/jquery/1.6.0/jquery.min.js');

	include('wpurl_header.php');
	include('wpurl_settings.php');
	include('wpurl_options.php');
	include('wpurl_footer.php');
}

function wpurlrotator_settings(){

	include('wpurl_settings.php');
	
}

require_once(plugin_dir_path(__FILE__).'wpurl_member_shortcode.php');

//========================================
// Begin Url Parameters
//========================================
//add_filter('query_vars', 'wpmckp_queryvars' );

//function wpmckp_queryvars( $qvars )
function wpurl_queryvars( $qvars )
{
$qvars[] = 'memid'; //Comments Here

//Can Declare More
return $qvars;
}

add_filter('query_vars', 'wpurl_queryvars' );
//========================================
// End Url Parameters
//========================================
