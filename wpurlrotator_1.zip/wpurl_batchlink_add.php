<?php
$rid = $_GET['rid'];
$pi_path = plugins_url()."/".dirname(plugin_basename(__FILE__))."/";
?>

<div align="center">
	<h1>Add A Batch of Links</h1>
	<a href="admin.php?page=wpurlrotator&rid=<?php echo $rid; ?>">Return to Link Admin</a>
	<form method="post" action="<?php echo $pi_path; ?>wpurl_dobatch_linkadd.php?rid=<?php echo $rid; ?>">
		<p>
	<div class="bTableForm" align="center">
		<div class="bTableRowForm">1. Enter the default values you would like the URLS loaded with for Name Prefix. 
			The default to be used will be batchurl. Each URL will be given a unique Rotator Name, like batchurl1, batchurl2, batchurl3 etc.
			<p>2. Enter the Enabled/Disabled, Weight and Maxhits you would like to be used for all URLs. The defaults are pre-loaded.
			<p>3. Enter one URL per line in the text box. You can copy and paste into this box. Make sure to hit Enter after your last link. 
			<p>
			
		</div>
		<div class="rTableBody">
			<div class="rTableRow">
				<div class="rTableHead">Name Prefix</div>
				<div class="rTableHeadr">Enabled/Disabled</div>
				<div class="rTableHead">Weight</div>
				<div class="rTableHead">Maxhits</div>
			</div>

			<div class="rTableRow">
				<div class="rTableCell"><input class="batchInputbox" name="name" id="name" size="10" type="text" value="batchurl" /></div>
				<div class="rTableCell">
					<input name="enabled" id="enabled" type="radio" value="Y" checked="Y">Yes 
					<input name="enabled" id="enabled" type="radio" value="N">No
				</div>
				<div class="rTableCell"><input class="inputbox" name="weight" id="weight" size="10" type="text" value="0" /></div>
				<div class="rTableCell"><input class="inputbox" name="maxhits" id="maxhits" size="10" type="text" value="0" /></div>
			</div>	

		</div>	

	</div>	

	<?php
	$displaywords = "<div class='bTableCell'><textarea name='keywords' value='$keywords' rows = '20' cols='80'>" ;
	$i=0;
	while($i<count($keyword_list)) {
		$displaywords .= $keyword_list[$i]."\r\n";
		$i++;
    }
	$displaywords .= "</textarea></div>";

	echo $displaywords;
	?>
	<div class="rTableCell"><input type="submit" name="submit" value="Submit URLs"></div>
	</form>
</div>	
	
	

	

