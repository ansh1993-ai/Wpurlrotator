<?php

$tday = date("Y-m-d"); 

// Get count info
$get_count = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix ."wpurlrotator_count WHERE camp_id = '".$Rid."' and cid = '".$CurrID."' and ipnum = '".$pip."' and date = '".$tday."' ");	

	if($get_count){
		// Name, ipnum and date exist
		
		$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_count SET number = number +1 WHERE camp_id = '".$Rid."' and cid = '".$CurrID."' and ipnum = '".$pip."' and date = '".$tday."'";
			$re=$wpdb->query($sql);

	} else {
		// Name and ipnum don't exist
		$ipcountry = visitor_country($pip);
		$sql=" INSERT INTO ".$wpdb->prefix."wpurlrotator_count (user, cid,date,number,ipnum,ipcnt,country,referredby, camp_id) VALUES('$CurrName','$CurrID','$tday',1,'$pip',1,'$ipcountry','$referredby', '$Rid')";
			$re=$wpdb->query($sql);

	}

$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_links SET cnt = cnt +1 WHERE camp_id = ".$Rid." and id = ".$CurrID."";
			$re=$wpdb->query($sql);



if ($Currmaxhits > 0) { 

	if($Currmaxhits == $Currmaxhits_cnt) {
		// Set next to 0 and find next url
		$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_links SET enabled = 'N' WHERE camp_id = ".$Rid." and id = ".$CurrID."";
		$re=$wpdb->query($sql);
	} else {
		$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_links SET maxhits_cnt = maxhits_cnt +1 WHERE camp_id = ".$Rid." and  id = ".$CurrID."";
		$re=$wpdb->query($sql);

	}
	
}

if($Currweight == 0) {
	$get_next_Url = hbr_find_next_url($CurrID, $Rid);

} else {
	if($Currweight > 0 && $Currweight_cnt == $Currweight){
		$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_links SET weight_cnt = 0 WHERE camp_id = ".$Rid." and  id = ".$CurrID." ";
		$re=$wpdb->query($sql);
		$get_next_Url = hbr_find_next_url($CurrID, $Rid);

	} else {
		$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_links SET weight_cnt = weight_cnt +1 WHERE camp_id = ".$Rid." and  id = ".$CurrID." ";
			$re=$wpdb->query($sql);

	}

}

	
function hbr_find_next_url($CurrID, $RotID){
	//require_once("../../../wp-load.php");
	global $wpdb;
	// Set Next to 0 for current id
	$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_links SET next = 0 WHERE camp_id = ".$RotID." and id = ".$CurrID."";
	$re=$wpdb->query($sql);
//echo "this is RotID ".$RotID;
		
	$get_count = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix ."wpurlrotator_links WHERE camp_id = ".$RotID." and enabled = 'Y' and Next = '1'");
	if(!$get_count){
		// Set Next URL
		$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_links SET next = 1 WHERE camp_id = ".$RotID." and id > ".$CurrID." and enabled = 'Y' ORDER BY id LIMIT 1";
		$re=$wpdb->query($sql);
	}

			// Could be the last ID, check to see there is an enabled ID from the first ID
	if($re == 0){
		$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_links SET next = 1 WHERE camp_id = ".$RotID." and id > 0 and enabled = 'Y' ORDER BY id LIMIT 1";
			$re=$wpdb->query($sql);	
				
		if($re == 0){
			//echo "no next found, use default URL"; 
		}
	}
}			


function visitor_country($ip) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if(filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        if(filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        $result = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip))
                ->geoplugin_countryName;
        return $result <> NULL ? $result : "Unknown";
}


			
