<?php


$id=$_GET['l'];
$pi_path = plugins_url()."/".dirname(plugin_basename(__FILE__))."/";

?>

<div align="center">
<h1><?php echo $iname; ?></h1>
<a href="admin.php?page=wpurlrotator">Return to Admin</a></div>

<div class="rTable">

	<div class="rTableBody">
		<div class="rTableRow">
			<div class="rTableHead">Link Name</div>
			<div class="rTableHead">Date</div>
			<div class="rTableHead">Total Direct Hits</div>
			<div class="rTableHead">Unique Direct Hits</div>
			<div class="rTableHead">IP</div>
			<div class="rTableHead">Country</div>
			<div class="rTableHead">Referring URL</div>
		</div>

		<?php

 		$re = $wpdb->get_results( "SELECT user, date, ipnum, sum(directhits) AS number, sum(directip) AS ipcnt, country, referredby FROM ".$wpdb->prefix."wpurlrotator_count WHERE cid = $id GROUP BY user, date, ipnum ORDER BY date DESC " );

 		
 		// $wpdb->query( $sql );
  		foreach ( $re as $ro ){

		  	if($ChangeColor == 0){
				$bgcolor = "#eaeaea" ;
				$ChangeColor = 1;
			} else {
				$bgcolor = "#FFFFFF" ;
				$ChangeColor = 0;
			}


			$id = $ro->id;
			$name = $ro->user;
			$date = $ro->date;
			$cnt = $ro->number;
			$ipcnt = $ro->ipcnt;
			$ipnum = $ro->ipnum;
			$country = $ro->country;
			$referredby = $ro->referredby;
			
			?>
			<div class="rTableRow">
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><?php echo $name; ?></div>
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><?php echo $date; ?></div>
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><?php echo $cnt; ?></div>
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><?php echo $ipcnt; ?></div>
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><?php echo $ipnum; ?></div>
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><?php echo $country; ?></div>
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><?php echo $referredby; ?></div>
			</div>	
			<?php

		}	

?>

	</div>
</div>

