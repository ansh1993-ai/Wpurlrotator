<?php

require_once("../../../wp-load.php");
global $wpdb;

$id = $_GET['l'];

$sql="DELETE FROM ".$wpdb->prefix."wpurlrotator_count WHERE camp_id ='$id'";
$wpdb->query( $sql );

$sql="DELETE FROM ".$wpdb->prefix."wpurlrotator_links WHERE camp_id ='$id'";
$wpdb->query( $sql );

$sql="DELETE FROM ".$wpdb->prefix."wpurlrotator_settings WHERE id ='$id'";
$wpdb->query( $sql );

 

header('location: '.admin_url().'admin.php?page=wpurlrotator');