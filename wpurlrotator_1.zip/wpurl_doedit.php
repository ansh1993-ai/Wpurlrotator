<?php

require_once("../../../wp-load.php");
global $wpdb;

$rid = $_POST['rid'];
$id = $_POST['id'];
$name = $_POST['name'];
$oldname = $_POST['oldname'];
$url = $_POST['url'];
$weight = $_POST['weight'];
$maxhits = $_POST['maxhits'];
$enabled = $_POST['enabled'];
$oldenabled = $_POST['oldenabled'];
$next = $_POST['next'];

if($enabled == 'N' && $next == '1'){
	// If this URL is next, we need to find the next enabled URL
	
	$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_links SET enabled = '$enabled' WHERE camp_id = '$rid' and id = '$id' ";
	
		$re=$wpdb->query($sql);

	require_once ('wpurl_update_tables.php');
	$get_next_Url = hbr_find_next_url($id, $rid);

} else {
		
		$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_links SET name = '$name', url = '$url', weight = '$weight', enabled = '$enabled', maxhits = '$maxhits' WHERE camp_id = '$rid' and id = '$id' ";
			$re=$wpdb->query($sql);

		if($name != $oldname) {
			// Named Changed
			$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_count SET user = '$name' WHERE camp_id = '$rid' and cid = '$id' "; 
				$re=$wpdb->query($sql);

		}	

}	

if($oldenabled == 'N' && $enabled == 'Y'){
	// This might be the only enabled url - have to check and set if it is.
	$get_next = $wpdb->get_row("SELECT id FROM ".$wpdb->prefix . "wpurlrotator_links WHERE camp_id = '$rid' and  next ='1' ");
		if($get_next == 0){
			$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_links SET next = '1' WHERE camp_id = '$rid' and id = '$id' ";
			$re=$wpdb->query($sql);
		}

}		

 header('location: '.admin_url().'admin.php?page=wpurlrotator&rid='.$rid);