<?

global $wpdb;
$rid = $_GET['rid'];
if (isset($_POST['bid'])) {
$batchids = $_POST['bid'];
$bataction = $_POST['batchAction'];

foreach($_POST['bid'] as $selected){

}
// "This is batchids ".$batchids;

$link_table = $wpdb->prefix."wpurlrotator_links";
$count_table = $wpdb->prefix."wpurlrotator_count";

$actionids = implode (",", $batchids);
	
	if ($bataction != "")
	{
		switch ($bataction)
		{
		case 'D':
			$sql= "UPDATE $link_table SET enabled = 'N' where id IN ($actionids)";
			$wpdb->query($sql);	
			
		break;
		case 'E':
			$sql= "UPDATE $link_table SET enabled = 'Y' where id IN ($actionids)";
			$wpdb->query($sql);	
		
		break;
		case 'R':
			$sql= "UPDATE $link_table SET cnt = 0, direct = 0 where id IN ($actionids)";
			$wpdb->query($sql);	

			$sql = "DELETE FROM $count_table WHERE cid IN ($actionids)";
			$wpdb->query($sql);	 

		break;
		case 'Del':
			$sql= "UPDATE $link_table SET enabled = 'N', next = 0 where id IN ($actionids)";
			$wpdb->query($sql);	
			
			$get_next = $wpdb->get_row("SELECT id FROM $link_table WHERE next ='1' and camp_id = '$rid' ");
			if($get_next == 0){
				// Get next ID function
				$last_id = end($batchids);
				$get_next_Url = hbr_find_next_url($last_id, $rid);
		}
			$sql = "DELETE FROM $count_table WHERE cid IN ($actionids)";
			$wpdb->query($sql);	 

			$sql = "DELETE FROM $link_table WHERE id IN ($actionids)";
			$wpdb->query($sql);	 
						
		break;	

	
		}
	}
}	



function hbr_find_next_url($CurrID, $rid){
	//require_once("../../../wp-load.php");
	global $wpdb;
	// Set Next to 0 for current id
	$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_links SET next = 0 WHERE id = ".$CurrID."";
	$re=$wpdb->query($sql);

		// Set Next URL
	$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_links SET next = 1 WHERE id > ".$CurrID." and enabled = 'Y' and camp_id = '$rid' LIMIT 1";
			$re=$wpdb->query($sql);


			// Could be the last ID, check to see there is an enabled ID from the first ID
	if($re == 0){
		$sql=" UPDATE ".$wpdb->prefix."wpurlrotator_links SET next = 1 WHERE id > 0 and enabled = 'Y' and camp_id = '$rid' LIMIT 1";
			$re=$wpdb->query($sql);	
				
		if($re == 0){
		//	echo "no next found, use default URL"; 
		}
	}
}
?>

<script type='text/javascript'>
window.location = "admin.php?page=wpurlrotator&rid=<?php echo $rid; ?>";

</script>