<?php

require_once("../../../wp-load.php");
global $wpdb;

$rid = $_GET['rid'];
$name = $_POST['name'];
//$name str_replace('/'/', '', $name);
$url = $_POST['url'];
$weight = $_POST['weight'];
$maxhits = $_POST['maxhits'];
$enabled = $_POST['enabled'];
//echo "this is rid in donew ".$rid;
 $table_name = $wpdb->prefix . "wpurlrotator_links";

$sql= "INSERT INTO $table_name (name, url, weight, maxhits, enabled, camp_id)
VALUES ('$name', '$url', '$weight', '$maxhits', '$enabled', '$rid')";	

$wpdb->query($sql);		

// Make sure there is a next URL since this may be the first URL entered
$get_next = $wpdb->get_row("SELECT id FROM ".$wpdb->prefix . "wpurlrotator_links WHERE camp_id = '$rid' and next ='1' ");
if($get_next == 0){
	require_once ('wpurl_update_tables.php');
	$get_next_Url = hbr_find_next_url(0, $rid);
}

 header('location: '.admin_url().'admin.php?page=wpurlrotator&rid='.$rid);

