<?php

$pi_path = plugins_url()."/".dirname(plugin_basename(__FILE__))."/";

$name = get_option("wpurl_member_page");

?>

<div align="center">
<h1>Enable Member Stats</h1>
<a href="admin.php?page=wpurlrotator">Close Member Stats</a></div>

<div class="helptexttable">
<ul>
<li><span class="tbtext"><strong>Member Stat Page Name</strong> This is optional. If you want members to be able to see the hits that have been sent to their URL, we need to create a short code on a page for them to be able to see their stats.
<p class="tbtext">You will need to:<br>
1. Create a PAGE with a name that will make sense, like MemberStats. I suggest using a page with no spaces to make it easier for you.<br/>
2. Place this short cold in the page - [wpurlmember]<br />
3. Come back here and place the page name in this form.
<p class="tbtext">
We will then be able to form a unique URL for each link that you can give to your members. They will only see their stats because of each unique URL.
<p class="tbtext">Important Note: We're only asking for this page name so we can setup the Member Stats URL for you. 

<p> </p>
</li>
</ul>
</div>



<form method="post" action="<?php echo $pi_path; ?>wpurl_domember.php">

<div class="rTableForm" align="center">
	<div class="rTableBodyForm">
		
		<div class="rTableRowForm">
			<div class="rTableCellForm">Member Stat Page Name</div>
			<div class="rTableCell"><input class="inputbox" name="name" id="name" size="50" type="text" value="<?php echo $name; ?>" /></div>
		</div>	
		<div class="rTableRowForm">		
			<div class="rTableCellForm"> </div>
			<div class="rTableCell"><input id="Submit" type="submit" value=" SAVE " /></div>
		</div>
	</div>
</div>
</form>

<br />


