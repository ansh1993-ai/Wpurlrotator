<?php

global $wpdb;
$camp_id = $_GET['rid'];
$baseurl = site_url();
//$pi_path = plugins_url()."/wpurlrotator/";
$pi_path = plugins_url()."/".dirname(plugin_basename(__FILE__))."/";

$re = $wpdb->get_results( " SELECT * FROM ".$wpdb->prefix."wpurlrotator_settings ORDER BY id ASC" );
if(!$re) {
echo "<center><h1>You must <a href='admin.php?page=wpurlrotator&a=nec&do=new'>create a rotator here</a> and then add links to your rotator.</h1><p>
";

} else {


	
	?>


<center>

<p>
<h1>Link Rotator Campaigns</H1>
	
<P>
<P><a href="admin.php?page=wpurlrotator&a=nec&do=new">Add New Rotator</a>      |      <a href="admin.php?page=wpurlrotator&a=ms">Enable Member Stats</a>      |      <a href="admin.php?page=wpurlrotator&a=rh" >Rotator Campaign Help</a>

<p>
<div class="sTable">
	<div class="rTableBody">
		<div class="rTableRow">
			<div class="rTableHead">Edit Rotator</div>
			<div class="rTableHead">Manage Links</div>
			<div class="rTableHead">Rotator Default Link</div>
			<div class="rTableHead">Links in Rotator</div>
			<div class="rTableHead">Rotator Hits</div>
			<div class="rTableHead">Delete Rotator</div>
			
		</div>

	


<?php

 //$re = $wpdb->get_results( " SELECT * FROM ".$wpdb->prefix."wpurlrotator_settings ORDER BY id ASC" );
 // $wpdb->query( $sql );
  foreach ( $re as $ro ){

  	if($ChangeColor == 0)
		{
			$bgcolor = "#eaeaea" ;
			$ChangeColor = 1;
		}
		else
		{
			$bgcolor = "#FFFFFF" ;
			$ChangeColor = 0;
		}


$rid = $ro->id;
$rname = $ro->rotator_name;
$rurl = $ro->default_url;
$linkcnt = $wpdb->get_row("select count(id) as linkcnt, sum(cnt) as hits FROM ".$wpdb->prefix."wpurlrotator_links WHERE camp_id = $rid ");
$links = $linkcnt->linkcnt;
$hits = $linkcnt->hits;
if ($rid == $camp_id){
	$rname = "<b><i><font color=red>".$rname."</font></b></i>";
	$rurl = "<b><i><font color=red>".$rurl."</font></b></i>";

}
?>


		<div class="rTableRow">
			<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<a href='admin.php?page=wpurlrotator&a=nec&do=edit&rid=<?php echo $rid; ?>'>Edit</a>
      		</div>
			<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<a href='admin.php?page=wpurlrotator&rid=<?php echo $rid; ?>'><?php echo $rname; ?></a>
      		</div>
      		<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<div><a href="<?php echo $url; ?>" ><?php echo $rurl; ?></a></div>
      		</div>
      		<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<div><?php echo $links; ?></div>
      		</div>
      		<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<div><?php echo $hits; ?></div>
      		</div>
      		<div class="rTableCell" background-color="<?php echo $bgcolor; ?>" >
				<a href="#" onclick="confirmDeleteRot(<?php echo $rid; ?>)">Delete</a>
      		</div>
      	</div>		
<?php
	}
	
?>
  	</div>
 </div> 	

<?php
echo "<b>Click on the rotator name under Manage Links to Add/Update/Delete links to be rotated</b>";

}



?>



<script type='text/javascript'>

var $ = jQuery.noConflict();
	
           function confirmDeleteRot(ID){
                         var c=confirm('Are you sure you want to delete this rotator and all associated links?');
                         if (c){
                                window.location='<?php echo $pi_path; ?>wpurl_delete_rotators.php?l='+ID;
                               }
                        }   
          
                     
</script>