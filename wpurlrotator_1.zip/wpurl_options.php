<?php

 $action=$_GET['a'];
   	if ($action==""){include('wpurl_admin.php');}
  	if ($action=="e"){include('wpurl_edit.php');}
  	if ($action=="n"){include('wpurl_new.php');}
  	if ($action=="d"){include('wpurl_delete.php');}
  	if ($action=="r"){include('wpurl_reset.php');}
  	if ($action=="b"){include('wpurl_batch.php');}
  	if ($action=="s"){include('wpurl_stats.php');}
  	if ($action=="ds"){include('wpurl_detail.php');}
  	if ($action=="bl"){include('wpurl_batchlink_add.php');}
  	if ($action=="rs"){include('wpurl_reset_counts.php');}
  	if ($action=="rwm"){include('wpurl_reset_weight_max.php');}
    if ($action=="dl"){include('wpurl_directlink.php');}
    if ($action=="h"){include('wpurl_help.php');}
    if ($action=="rh"){include('wpurl_rotator_help.php');}
    if ($action=="dls"){include('wpurl_direct_stats.php');}
    if ($action=="dld"){include('wpurl_direct_detail.php');}
    if ($action=="er"){include('wpurl_edit_rotator.php');}
    if ($action=="nec"){include('wpurl_new_campaign.php');}
    if ($action=="ms"){include('wpurl_member.php');}
	if ($action=="ml"){include('wpurl_memberlinks.php');}