<?php


require_once("../../../wp-load.php");
global $wpdb;

$name = $_POST['rotator'];
$oldname = $_POST['oldname'];
$url = $_POST['url'];
$rid = $_GET['rid'];
$do = $_GET['do'];
//echo "this is name ".$name." and old name ".$oldname;

$name = str_replace('/','',$name);
$name = str_replace(' ','',$name);
$name = str_replace(',','',$name);
$name = str_replace('%','',$name);
$name = str_replace('&','',$name);

 $table_name = $wpdb->prefix . "wpurlrotator_settings";
//echo "this is name ".$name;
 $get_rotator = $wpdb->get_row("SELECT * FROM $table_name WHERE rotator_name ='$name'");
 
			//	$rotator = $get_rotator->rotator_name;
			//	$def_url = $get_rotator->default_url;
				//echo "this is roator ".$rotator;
if ($get_rotator && ($oldname != $name))
 {
 	//echo "exists";
 	header('location: '.admin_url().'admin.php?page=wpurlrotator&a=nec&do='.$do.'&rid='.$rid.'&exists=y&name='.$name.'');
 } else {

	if (!$rid) {
		$sql= "INSERT INTO $table_name (rotator_name, default_url)
		VALUES ('$name', '$url')";	
	} else {
		$sql= "UPDATE $table_name SET rotator_name = '$name', default_url = '$url' WHERE id = '$rid' ";
		//echo "this is $name ".$name." and url ".$url;
	}																				

	$wpdb->query($sql);	

header('location: '.admin_url().'admin.php?page=wpurlrotator');
}	


