<?php

$rid = $_GET['rid'];
//echo "this is rid ".$rid;
$baseurl = site_url();
$get_next = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix . "wpurlrotator_settings where id = '$rid'");
	if ($get_next){
		$RotatorName = $get_next->rotator_name;
		$DefaultURL = $get_next->default_url;
	}

?>

<div align="center">
<h1><?php echo $RotatorName; ?></h1>
<p>
<a href="admin.php?page=wpurlrotator&rid=<?php echo $rid; ?>">Return to Admin</a></div>

<div class="sTable">

	<div class="rTableBody">
		<div class="rTableRow">
			<div class="rTableHead">Link Name</div>
			<div class="rTableHead">Direct URL</div>

		</div>

		<?php

 		$re = $wpdb->get_results( "SELECT id, name, url, camp_id FROM ".$wpdb->prefix."wpurlrotator_links WHERE camp_id = '$rid'" );

 		
 		// $wpdb->query( $sql );
  		foreach ( $re as $ro ){

		  	if($ChangeColor == 0){
				$bgcolor = "#eaeaea" ;
				$ChangeColor = 1;
			} else {
				$bgcolor = "#FFFFFF" ;
				$ChangeColor = 0;
			}


			$id = $ro->id;
			$name = $ro->name;
			$url = $ro->url;
			$camp_id = $ro->camp_id;
			$url = $baseurl."/".$RotatorName."/".$id;
			
			
			?>
			<div class="rTableRow">
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><?php echo $name; ?></div>
				<div class="rTableCell" background-color="<?php echo $bgcolor; ?>"><a href="<?php echo $url; ?>" target="_blank"><?php echo $url; ?></a></div>

			</div>	
			<?php

		}	

?>

	</div>
</div>

