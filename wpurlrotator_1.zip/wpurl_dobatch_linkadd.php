<?php

require_once("../../../wp-load.php");
global $wpdb;
$table_name = $wpdb->prefix . "wpurlrotator_links";
$rid = $_GET['rid'];
$keywords = $_POST["keywords"];
$name = $_POST["name"];
$enabled = $_POST["enabled"];
$weight = $_POST["weight"];
$maxhits = $_POST["maxhits"];

$data = explode("\r\n",$keywords);
	$count = count($data);
	
	for ($cnt=0;$cnt<$count;$cnt++)
		{
	
        $linkname = $name.$setname;
		$set = "next = 0,";
		$set .= "name  = '$linkname'," ;
        $set .= "url  = '$data[$cnt]'," ;
        $set .= "cnt = 0,";
		$set .= "weight  = '$weight'," ;
        $set .= "maxhits  = '$maxhits'," ;
        $set .= "enabled  = '$enabled'," ;
        $set .= "camp_id = '$rid'";
		if ($data[$cnt] != '') {
			
			$sql= "INSERT INTO $table_name set $set";
			$wpdb->query($sql);		
			$setname++;
			$urlcnt++;
			
		}
	}

	// Make sure there is a next URL since this may be the first URL entered
$get_next = $wpdb->get_row("SELECT id FROM ".$wpdb->prefix . "wpurlrotator_links WHERE next ='1' and camp_id = '$rid'");
if($get_next == 0){
	require_once ('wpurl_update_tables.php');
	$get_next_Url = hbr_find_next_url(0, $rid);
}
header('location: '.admin_url().'admin.php?page=wpurlrotator&rid='.$rid);
